function Iteration_Algv=GetStandardDeviation(Iteration_Alg,Iteration_Algm,n_iteration)
[n_point,n_MonteCarlo]=size(Iteration_Alg);
Iteration_Algv=zeros(n_point,1);
for i_point=1:n_point
    sum=0;
    num=0;
    for i_MonteCarlo=1:n_MonteCarlo

        if (Iteration_Alg(i_point,i_MonteCarlo)>0) && (Iteration_Alg(i_point,i_MonteCarlo)<n_iteration)
            sum=sum+(Iteration_Alg(i_point,i_MonteCarlo)-Iteration_Algm(i_point))^2;
            num=num+1;
        end
    end
    Iteration_Algv(i_point)=sqrt(sum/num);
end
