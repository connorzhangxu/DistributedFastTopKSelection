function [Loc]=RequiredIteration2(Error,Delta)

n_iteration=length(Error);
Ind=(Error<=Delta/2);
One_loc=find(Ind==1);
Loc=One_loc(1);