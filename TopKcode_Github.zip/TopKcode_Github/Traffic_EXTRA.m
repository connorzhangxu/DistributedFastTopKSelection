%% Communication cost for distributed top-k selection via EXTRA

clc
clear
close all
addpath(genpath('./utils/'));
addpath(genpath('./algorithms/'));

N=1e4;
n=1e3;

n_iteration=1e4;
n_MonteCarlo=100;
Delta = 0.1; % Resolution
step=100;

% loss='l2';
% loss='l1';
loss='inf';
% smooth='Nesterov';
smooth='Convolution';


%% set random seed
seed=100;
rng(seed);

%% generate Erdo Renyi random graph
NumEdges=3*n;
[A]=RandomGraphGeneration(n,NumEdges);
% end
% load('graph1e3.mat')
% figure
% plot(graph(A))
% diameter
dmax=max(sum(A));
D=diag(sum(A));
L=D-A;
lambda=svd(L);
NumEdges=sum(sum(A))/2;

%% Main program
NetworkTraffic=zeros(n,1);
beta0=2/(lambda(1)+lambda(n-1));

Error_EXTRA=zeros(n_iteration,n_MonteCarlo);
Iteration_EXTRA=zeros(n/step,n_MonteCarlo);

for t_MonteCarlo=1:n_MonteCarlo
    t_MonteCarlo
    %% generate signal with resolution delta
    % x=randi(N/10,[N 1])*Delta;
    x=round(randn(N,1)*sqrt(10)/Delta)*Delta;
    data=RandAssignData(N,n,x);
    for k=step:step:N-step
        p=(N-k+0.5)/N;
        [y,~]=sort(x,'descend');
        m_over=k-sum(x>y(k));
        m_under=N-k-sum(x<y(k));
        gm=min(m_over-0.5,m_under+0.5);
        threshold=y(k);
        W=eye(n)-beta0*L;
        % Sigma=svd(W);
        flag=0;
        h=Delta*0.2;
        tic
        while flag==0

            Error_EXTRA(:,t_MonteCarlo)=DistributedQuantileEstimation_EXTRA_MultNum(data,threshold,p,A,beta0,h,n_iteration,Delta,loss,smooth);

            if  Error_EXTRA(n_iteration,t_MonteCarlo)<= Delta/2
                flag=1;
            end
            h=h*0.95;
            toc
            if toc>50
                break;
            end
        end
        if  Error_EXTRA(n_iteration,t_MonteCarlo)<= Delta/2
            Iteration_EXTRA(k/step,t_MonteCarlo)=RequiredIteration2(Error_EXTRA(:,t_MonteCarlo),Delta);
        end

    end
end

Iteration_EXTRAm=GetAverage(Iteration_EXTRA,n_iteration);
Iteration_EXTRAv=GetStandardDeviation(Iteration_EXTRA,Iteration_EXTRAm,n_iteration);

plot(Iteration_EXTRAm*NumEdges)


