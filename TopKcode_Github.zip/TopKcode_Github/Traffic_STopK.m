%% Communication cost for distributed top-k selection via STopK

clc
clear
close all
addpath(genpath('./utils/'));
addpath(genpath('./algorithms/'));

N=1e4;
n=1e3;

n_iteration=1e4;
n_MonteCarlo=1;

Delta = 0.1; % Resolution
step=100;

%% set random seed
seed=100;
rng(seed);

%% generate Erdo Renyi random graph
NumEdges=3*n;
[A]=RandomGraphGeneration(n,NumEdges);
DG= distances(graph(A));
diameter=max(max(DG));
% figure
% plot(graph(A))
% diameter
% dmax=max(sum(A));
% D=diag(sum(A));
% L=D-A;
% lambda=svd(L);

%% Main program

NetworkTraffic=zeros(N,1);

for t_MonteCarlo=1:n_MonteCarlo
    t_MonteCarlo
    %% generate signal with resolution delta

    %% generate signal with resolution Delta
    x=round(randn(N,1)*sqrt(10)/Delta)*Delta;
    Data=RandAssignData2(N,n,x);

    for k=step:step:N-step
        k
        p=(N-k+0.5)/N;
        [y,~]=sort(x,'descend');
        data=Data;

        if k<=N/2
            for i=1:n
                if sum(data(i,:)~=-inf)>=k
                    [~,index]=sort(data(i),'descend');
                    data(i,index(k+1:end))=-inf;
                end
            end
            data_old=data;

            for t_iteration=1:diameter
                for i=1:n
                    for j=1:n
                        if A(i,j)==1
                            index_tmp=find(data_old(j,:)~=-inf);
                            data(i,index_tmp)=data_old(j,index_tmp);
                            NetworkTraffic(k)=NetworkTraffic(k)+sum(data_old(j,:)~=-inf);
                        end
                    end
                end

                for i=1:n
                    [~,index_s]=sort(data(i,:),'descend');
                    data(i,index_s(k+1:end))=-inf;
                end

                data_old=data;
            end
        else
            NetworkTraffic(k)= NetworkTraffic(N-k+step);
        end
    end
end
%% Figure
plot(NetworkTraffic(step:step:N-step)/n_MonteCarlo)



